const employeeList = document.getElementById('employee-list');
const employeeForm = document.getElementById('employee-form');
const errorMessage = document.getElementById('error-message');
const updateButton = document.getElementById('update-button');
const searchInput = document.getElementById('search-input');
const employeeTable = document.querySelector('.employee-table');

// Function to fetch and display employees from the server
async function fetchEmployees() {
    try {
        const response = await fetch('/getEmployees');
        if (!response.ok) throw new Error('Failed to retrieve employees');

        const employees = await response.json();
        displayEmployees(employees);
    } catch (error) {
        console.error('Error fetching employees:', error.message);
    }
}

// Function to display employees in the table
function displayEmployees(employees) {
    employeeList.innerHTML = '';
    employees.forEach(emp => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${emp.id}</td>
            <td>${emp.name}</td>
            <td>${emp.gender}</td>
            <td>${emp.DOJ}</td>
            <td>${emp.position}</td>
            <td>${emp.project}</td>
            <td>${emp.salary}</td>
            <td>${emp.DOB}</td>
            <td>${emp.Email}</td>
            <td>${emp.address}</td>
            <td>
                <button onclick="editEmployee('${emp.id}')">Edit</button>
                <button onclick="deleteEmployee('${emp.id}')">Delete</button>
            </td>
        `;
        employeeList.appendChild(row);
    });
    employeeTable.style.display = employees.length > 0 ? 'table' : 'none';
}

// Add a new employee
employeeForm.addEventListener('submit', async (event) => {
    event.preventDefault();

    const newEmployee = {
        id: document.getElementById('emp-id').value,
        name: document.getElementById('name').value,
        gender: document.getElementById('gender').value,
        DOJ: document.getElementById('DOJ').value,
        position: document.getElementById('position').value,
        project: document.getElementById('project').value,
        salary: document.getElementById('salary').value,
        DOB: document.getElementById('DOB').value,
        Email: document.getElementById('Email').value,
        address: document.getElementById('address').value
    };

    try {
        const response = await fetch('/addEmployee', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newEmployee)
        });

        if (!response.ok) throw new Error('Employee ID already exists or invalid data');
        
        fetchEmployees();  // Refresh the employee list
        employeeForm.reset();
        errorMessage.textContent = '';
    } catch (error) {
        errorMessage.textContent = error.message;
        console.error('Error adding employee:', error.message);
    }
});

// Edit an existing employee
function editEmployee(id) {
    fetch(`/getEmployees`)  // Fetch the list to find the employee by ID
        .then(response => response.json())
        .then(employees => {
            const employee = employees.find(emp => emp.id === id);
            if (employee) {
                document.getElementById('emp-id').value = employee.id;
                document.getElementById('name').value = employee.name;
                document.getElementById('gender').value = employee.gender;
                document.getElementById('DOJ').value = employee.DOJ;
                document.getElementById('position').value = employee.position;
                document.getElementById('project').value = employee.project;
                document.getElementById('salary').value = employee.salary;
                document.getElementById('DOB').value = employee.DOB;
                document.getElementById('Email').value = employee.Email;
                document.getElementById('address').value = employee.address;
                updateButton.style.display = 'block';
            }
        })
        .catch(error => console.error('Error fetching employee details:', error));
}

// Update an employee's details
updateButton.addEventListener('click', async () => {
    const id = document.getElementById('emp-id').value;
    const updatedEmployee = {
        name: document.getElementById('name').value,
        gender: document.getElementById('gender').value,
        DOJ: document.getElementById('DOJ').value,
        position: document.getElementById('position').value,
        project: document.getElementById('project').value,
        salary: document.getElementById('salary').value,
        DOB: document.getElementById('DOB').value,
        Email: document.getElementById('Email').value,
        address: document.getElementById('address').value
    };

    try {
        const response = await fetch(`/updateEmployee/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updatedEmployee)
        });

        if (!response.ok) throw new Error('Failed to update employee');

        fetchEmployees();  // Refresh the employee list
        employeeForm.reset();
        updateButton.style.display = 'none';
        errorMessage.textContent = '';
    } catch (error) {
        errorMessage.textContent = error.message;
        console.error('Error updating employee:', error.message);
    }
});

// Delete an employee
async function deleteEmployee(id) {
    try {
        const response = await fetch(`/deleteEmployee/${id}`, { method: 'DELETE' });
        if (!response.ok) throw new Error('Failed to delete employee');

        fetchEmployees();  // Refresh the employee list
    } catch (error) {
        console.error('Error deleting employee:', error.message);
    }
}

// Search employees by ID
searchInput.addEventListener('input', function() {
    const searchTerm = this.value.toLowerCase();

    fetch('/getEmployees')
        .then(response => response.json())
        .then(employees => {
            const filteredEmployees = employees.filter(emp => emp.id.toLowerCase().includes(searchTerm));
            displayEmployees(filteredEmployees);
        })
        .catch(error => console.error('Error fetching employees for search:', error));
});
