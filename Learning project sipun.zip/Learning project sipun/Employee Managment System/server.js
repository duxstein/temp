const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Database setup for MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',       // Replace with your MySQL username
    password: 'root',   // Replace with your MySQL password
    database: 'sipun'   // Replace with your MySQL database name
});

// Connect to MySQL
db.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL database:', err.message);
        return;
    }
    console.log('Connected to the MySQL database.');
});

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files from the 'public' folder

// Route to display the landing page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Landingpage.html'));
});

// Route to display the view employees page
app.get('/viewemployee', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'viewemployees.html'));
});

// API route to retrieve all employees (used by viewemployees.html)
app.get('/getEmployees', (req, res) => {
    const selectQuery = `SELECT * FROM sipun12`;

    db.query(selectQuery, (err, rows) => {
        if (err) {
            console.error('Error fetching employees:', err.message);
            return res.status(500).json({ error: 'Failed to retrieve employees' });
        }
        res.json(rows);
    });
});

// API route to add a new employee
app.post('/addEmployee', (req, res) => {
    const { id, name, gender, DOJ, position, project, salary, DOB, Email, address } = req.body;

    const insertQuery = `INSERT INTO sipun12 (id, name, gender, DOJ, position, project, salary, DOB, Email, address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    db.query(insertQuery, [id, name, gender, DOJ, position, project, salary, DOB, Email, address], (err, result) => {
        if (err) {
            console.error('Error inserting employee:', err.message);
            return res.status(400).json({ error: 'Employee ID already exists or invalid data' });
        }
        res.json({ message: 'Employee added successfully' });
    });
});
app.put('/updateEmployee/:id', (req, res) => {
    const { name, gender, DOJ, position, project, salary, DOB, Email, address } = req.body;
    const employeeId = req.params.id;

    console.log('Attempting to update employee with ID:', employeeId);
    console.log('Data received:', req.body);

    const updateQuery = `
        UPDATE sipun12 
        SET name = ?, gender = ?, DOJ = ?, position = ?, project = ?, salary = ?, DOB = ?, Email = ?, address = ?
        WHERE id = ?`;

    db.query(updateQuery, [name, gender, DOJ, position, project, salary, DOB, Email, address, employeeId], (err, result) => {
        if (err) {
            console.error('Error updating employee:', err); // Log full error object
            return res.status(500).json({ error: `Failed to update employee: ${err.message}` });
        }

        if (result.affectedRows === 0) {
            console.warn(`No employee found with ID ${employeeId}`);
            return res.status(404).json({ error: 'Employee not found' });
        }

        console.log(`Employee with ID ${employeeId} updated successfully`);
        res.json({ message: 'Employee updated successfully' });
    });
});



// API route to delete an employee by ID
app.delete('/deleteEmployee/:id', (req, res) => {
    const deleteQuery = `DELETE FROM sipun12 WHERE id = ?`;

    db.query(deleteQuery, [req.params.id], (err, result) => {
        if (err) {
            console.error('Error deleting employee:', err.message);
            return res.status(500).json({ error: 'Failed to delete employee' });
        }
        res.json({ message: 'Employee deleted successfully' });
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
